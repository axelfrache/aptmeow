# multitime-deb

**frache-time** is a simple command-line tool written in Python that displays the current time in three time zones:  
- GMT (UTC)  
- Tuvalu (UTC+12)  
- France (Europe/Paris)  

This project was created as part of a Debian packaging exercise.

---

## 📦 Package

To build the `.deb` package from the project folder:

```bash
dpkg-deb --build frache-time
```

To install the package:
```bash
apt install ./frache-time.deb
```

Run the tool:
```bash
frache-time
```